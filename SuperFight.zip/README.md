# SuperFight

  Exclusion codes are hex values that will later be converted to binary
  
  |Type| Characters |Powers |Win Conds |Arenas|
  |:----:|:---:|:---:|:---:|:---:|
 |0|0|0|0|0|
|1|0|0|0|1|
|2|0|0|1|0|
|3|0|0|1|1|
|4|0|1|0|0|
|5|0|1|0|1|
|6|0|1|1|0|
|7|0|1|1|1|
|8|1|0|0|0|
|9|1|0|0|1|
|10|1|0|1|0|
|11|1|0|1|1|
|12|1|1|0|0|
|13|1|1|0|1|
|14|1|1|1|0|
|15|1|1|1|1|
